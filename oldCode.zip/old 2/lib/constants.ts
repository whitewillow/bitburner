export const SERVER_PREFIX = 'pserv-';
